
void join_privatewingman();
void join_indianhvhalpha();
void join_indianhvhbeta();
void join_indianhvhdelta();
void join_indianhvhgamma();
void join_ragepubindia();
void join_ragepubsgp();
void join_Ramen();
void join_shushi();
void join_cthook();
void join_r7server();
void join_rantie$();