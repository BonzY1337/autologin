#pragma once

void run_nemesis();
void run_monolith();
void run_evolve();
void run_crep();
void run_skeet();
void run_cr0nus();
void run_fatality();
void run_kidua();
void run_pureskills();
void run_royalhacks();
void run_2k17();
void run_luminus();

