#pragma once

void print_menu();
