#pragma once
void displayclock();
void timer();