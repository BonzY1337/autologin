#include "joinserver.h"
#include <Windows.h>


void join_privatewingman()
{
	system("start steam://connect/13.126.120.226 /uwuonzy");
}

void join_indianhvhalpha()
{
	system("start steam://connect/13.127.68.194:27015");
}

void join_indianhvhbeta()
{
	system("start steam://connect/13.126.111.72:27015");
}

void join_indianhvhdelta()
{
	system("start steam://connect/15.206.180.17:27015");
}

void join_indianhvhgamma()
{
	system("start steam://connect/13.232.248.170:27015");
}

void join_ragepubindia()
{
	system("start steam://connect/3.6.67.4:27033");
}

void join_ragepubsgp()
{
	system("start steam://connect/139.99.16.124:27033");
}

void join_Ramen()
{
	system("start steam://connect/139.99.7.207:27015");
}

void join_shushi()
{
	system("start steam://connect/139.99.118.243:27015");
}

void join_cthook()
{
	system("start steam://connect/213.133.100.228:27024");
}

void join_r7server()
{
	system("start steam://connect/54.37.90.233:27015");
}

void join_rantie$()
{
	system("start steam://connect/149.202.65.10:27035");
}