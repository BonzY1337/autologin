#pragma once

namespace globals
{
	extern const char* killsteamservice;
	extern const char* killsteamwebhelper;
	extern const char* killsteam;
	extern const char* killcsgo;
	extern const char* startcsgo;
	extern const char* startsteamcustomid;
	extern const char* startsteam;
}