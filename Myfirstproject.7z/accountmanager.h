#pragma once
#include <iostream>
#include <string>
#include <sstream>
#include <stdlib.h>
#include <fstream>
#include <time.h>
#include <vector>
#include <Windows.h>
#include <TlHelp32.h>
#include "global.h"
#include "colored_cout.h"

void printaccounts();
int loginnonprime();
void loginaccount2();
void loginYuzu();
int boost();


