#pragma once

void print_menuserver();

void print_private();

void print_india();

void print_asia();

void print_eu();
